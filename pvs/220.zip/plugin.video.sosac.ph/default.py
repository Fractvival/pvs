# -*- coding: UTF-8 -*-
# /*
#  *      Copyright (C) 2013 Libor Zoubek + jondas
#  *
#  *
#  *  This Program is free software; you can redistribute it and/or modify
#  *  it under the terms of the GNU General Public License as published by
#  *  the Free Software Foundation; either version 2, or (at your option)
#  *  any later version.
#  *
#  *  This Program is distributed in the hope that it will be useful,
#  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  *  GNU General Public License for more details.
#  *
#  *  You should have received a copy of the GNU General Public License
#  *  along with this program; see the file COPYING.  If not, write to
#  *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  *  http://www.gnu.org/copyleft/gpl.html
#  *
#  */

import sys
import xbmcaddon
from resources.lib import xbmcutil
from resources.lib.sosac import SosacContentProvider
from resources.lib.sutils import XBMCSosac
from resources.lib import util
from resources.lib.config import config
from resources.lib.util import logger

__scriptid__ = 'plugin.video.sosac.ph'
__scriptname__ = 'sosac.ph'
__addon__ = xbmcaddon.Addon(__scriptid__)
__language__ = __addon__.getLocalizedString

def main():
    """Main entry point with enhanced error handling"""
    try:
        # Log startup information
        logger.info("="*50)
        logger.info(f"Starting {__scriptname__} addon")
        logger.info(f"Arguments: {sys.argv}")
        logger.info(f"URL: {sys.argv[2] if len(sys.argv) > 2 else 'None'}")
        
        # Get parameters
        params = util.params()
        logger.info(f"Parsed params: {params}")
        
        # Use new configuration manager for settings
        settings = config.get_legacy_settings()
        
        # Log configuration (without sensitive data)
        logger.debug(f"Configuration loaded - Quality: {config.quality}, Language: {config.language}")
        
        # Validate configuration
        if config.downloads_path and not config.validate_downloads_path():
            logger.warning("Downloads path is not accessible, downloads may fail")
        
        # Create provider with enhanced configuration
        sosac = SosacContentProvider(
            reverse_eps=config.reverse_episodes,
            force_czech=config.force_czech,
            order_recently_by=config.order_recently_by
        )
        
        # Set streaming credentials
        sosac.streamujtv_user = config.streamujtv_user
        sosac.streamujtv_pass = config.streamujtv_pass
        sosac.streamujtv_location = config.streamujtv_location
        
        # Run the addon
        XBMCSosac(sosac, settings, __addon__).run(params)
        
        logger.info("Addon execution completed successfully")
        
    except Exception as e:
        logger.fatal(f"Critical error in main execution: {e}")
        # Show user-friendly error dialog
        import xbmcgui
        xbmcgui.Dialog().notification(
            'Sosáč Error', 
            'An error occurred. Check logs for details.',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        raise

if __name__ == '__main__':
    main()
