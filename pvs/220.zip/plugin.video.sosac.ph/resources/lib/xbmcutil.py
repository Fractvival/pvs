# -*- coding: UTF-8 -*-
# /*
# *      Copyright (C) 2011 Libor Zoubek
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */
import os
import re
import sys
import urllib
import urllib.request
import urllib.parse
import traceback
import http.cookiejar
import time
import socket
import unicodedata
import xbmcgui
import xbmcplugin
import xbmc
import xbmcvfs
import xbmcaddon
from html.entities import name2codepoint as n2cp
import json
from . import util
from . import utmain

UA = 'Mozilla/6.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.5) Gecko/2008092417 Firefox/3.0.3'

sys.path.append(os.path.join(os.path.dirname(__file__), 'usage'))

__addon__ = xbmcaddon.Addon('plugin.video.sosac.ph')
__lang__ = __addon__.getLocalizedString


##
# initializes urllib cookie handler


def init_urllib():
    cj = http.cookiejar.LWPCookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    urllib.request.install_opener(opener)


def request(url, headers=None):
    if headers is None:
        headers = {}
    debug('request: %s' % url)
    req = urllib.request.Request(url, headers=headers)
    response = urllib.request.urlopen(req)
    data = response.read()
    response.close()
    debug('len(data) %s' % len(data))
    return data.decode("utf-8")


def post(url, data):
    postdata = urllib.parse.urlencode(data)
    req = urllib.request.Request(url, postdata)
    req.add_header('User-Agent', UA)
    response = urllib.request.urlopen(req)
    data = response.read()
    response.close()
    return data


def icon(name):
    return 'https://github.com/lzoubek/xbmc-doplnky/raw/dharma/icons/' + name


def substr(data, start, end):
    i1 = data.find(start)
    i2 = data.find(end, i1)
    return data[i1:i2]


def add_dir(name, params, logo='', infoLabels={}, menuItems={}):
    name = decode_html(name)
    if not 'title' in infoLabels:
        infoLabels['title'] = ''
    if logo == None:
        logo = ''
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': 'DefaultFolder.png', 'thumb': logo})
    try:
        # Use modern video info tag methods
        video_info_tag = liz.getVideoInfoTag()
        
        # Map common properties to modern API
        if 'title' in infoLabels:
            video_info_tag.setTitle(infoLabels['title'])
        if 'plot' in infoLabels:
            video_info_tag.setPlot(infoLabels['plot'])
        if 'year' in infoLabels:
            video_info_tag.setYear(int(infoLabels['year']))
        if 'genre' in infoLabels:
            video_info_tag.setGenres([infoLabels['genre']])
        if 'rating' in infoLabels:
            video_info_tag.setRating(float(infoLabels['rating']))
        if 'director' in infoLabels:
            video_info_tag.setDirectors([infoLabels['director']])
        if 'cast' in infoLabels:
            video_info_tag.setCast(infoLabels['cast'])
        if 'duration' in infoLabels:
            video_info_tag.setDuration(int(infoLabels['duration']))
        if 'tvshowtitle' in infoLabels:
            video_info_tag.setTvShowTitle(infoLabels['tvshowtitle'])
        if 'season' in infoLabels:
            video_info_tag.setSeason(int(infoLabels['season']))
        if 'episode' in infoLabels:
            video_info_tag.setEpisode(int(infoLabels['episode']))
    except Exception as e:
        # Fallback to old method for older Kodi versions
        try:
            liz.setInfo(type='Video', infoLabels=infoLabels)
        except:
            traceback.print_exc()
    items = []
    for mi in menuItems.keys():
        action = menuItems[mi]
        if not type(action) == type({}):
            items.append((mi, action))
        else:
            if 'action-type' in action:
                action_type = action['action-type']
                del action['action-type']
                if action_type == 'list':
                    items.append((mi, 'Container.Update(%s)' % _create_plugin_url(action)))
                elif action_type == 'play':
                    items.append((mi, 'PlayMedia(%s)' % _create_plugin_url(action)))
                else:
                    items.append((mi, 'RunPlugin(%s)' % _create_plugin_url(action)))
            else:
                items.append((mi, 'RunPlugin(%s)' % _create_plugin_url(action)))
    if len(items) > 0:
        liz.addContextMenuItems(items)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_create_plugin_url(params),
                                       listitem=liz, isFolder=True)


def add_local_dir(name, url, logo='', infoLabels={}, menuItems={}):
    name = decode_html(name)
    infoLabels['Title'] = name
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': 'DefaultFolder.png', 'thumb': logo})
    # Use modern video info tag methods
    try:
        video_info_tag = liz.getVideoInfoTag()
        
        # Map common properties to modern API  
        if 'Title' in infoLabels:
            video_info_tag.setTitle(infoLabels['Title'])
        if 'title' in infoLabels:
            video_info_tag.setTitle(infoLabels['title'])
        if 'plot' in infoLabels:
            video_info_tag.setPlot(infoLabels['plot'])
        if 'year' in infoLabels:
            video_info_tag.setYear(int(infoLabels['year']))
        if 'genre' in infoLabels:
            video_info_tag.setGenres([infoLabels['genre']])
    except:
        # Fallback to old method for older Kodi versions
        liz.setInfo(type='Video', infoLabels=infoLabels)
    items = []
    for mi in menuItems.keys():
        items.append((mi, 'RunPlugin(%s)' % _create_plugin_url(menuItems[mi])))
    if len(items) > 0:
        liz.addContextMenuItems(items)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz,
                                       isFolder=True)


def add_video(name, params={}, logo='', infoLabels={}, menuItems={}):
    name = decode_html(name)
    if not 'Title' in infoLabels:
        infoLabels['Title'] = name
    url = _create_plugin_url(params)
    li = xbmcgui.ListItem(name, path=url)
    li.setArt({'icon': 'DefaultVideo.png', 'thumb': logo})
    
    # Use new video info tag methods
    video_info_tag = li.getVideoInfoTag()
    
    # Map common video properties
    if 'title' in infoLabels:
        video_info_tag.setTitle(infoLabels['title'])
    if 'plot' in infoLabels:
        video_info_tag.setPlot(infoLabels['plot'])
    if 'year' in infoLabels:
        video_info_tag.setYear(int(infoLabels['year']))
    if 'genre' in infoLabels:
        video_info_tag.setGenres([infoLabels['genre']])
    if 'rating' in infoLabels:
        video_info_tag.setRating(float(infoLabels['rating']))
    if 'director' in infoLabels:
        video_info_tag.setDirectors([infoLabels['director']])
    if 'cast' in infoLabels:
        video_info_tag.setCast(infoLabels['cast'])
    if 'duration' in infoLabels:
        video_info_tag.setDuration(int(infoLabels['duration']))
    if 'tvshowtitle' in infoLabels:
        video_info_tag.setTvShowTitle(infoLabels['tvshowtitle'])
    if 'season' in infoLabels:
        video_info_tag.setSeason(int(infoLabels['season']))
    if 'episode' in infoLabels:
        video_info_tag.setEpisode(int(infoLabels['episode']))
    
    try:
        # Create proper VideoStreamDetail object
        from xbmc import VideoStreamDetail
        videoStream = VideoStreamDetail(
            width=1920,
            height=1080,
            codec='h264',
            aspect=1.78,
            duration=0
        )
        video_info_tag.addVideoStream(videoStream)
        
        # Add audio stream if needed
        from xbmc import AudioStreamDetail
        audioStream = AudioStreamDetail(
            channels=2,
            codec='aac',
            language='eng'
        )
        video_info_tag.addAudioStream(audioStream)
    except:
        # Fallback to old method if VideoStreamDetail is not available
        li.setInfo('video', infoLabels)
    
    li.setProperty('IsPlayable', 'true')
    
    # Context menu items
    items = [(xbmc.getLocalizedString(13347), 'Action(Queue)')]
    for mi in menuItems.keys():
        action = menuItems[mi]
        if not isinstance(action, dict):
            items.append((mi, action))
        else:
            if 'action-type' in action:
                action_type = action['action-type']
                del action['action-type']
                if action_type == 'list':
                    items.append((mi, 'Container.Update(%s)' % _create_plugin_url(action)))
                elif action_type == 'play':
                    items.append((mi, 'PlayMedia(%s)' % _create_plugin_url(action)))
                else:
                    items.append((mi, 'RunPlugin(%s)' % _create_plugin_url(action)))
            else:
                items.append((mi, 'RunPlugin(%s)' % _create_plugin_url(action)))

    if len(items) > 0:
        li.addContextMenuItems(items)
        
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li,
                                     isFolder=False)


def _create_plugin_url(params, plugin=sys.argv[0]):
    url = []
    for key in params.keys():
        value = decode_html(params[key])
        # --value = value.encode('ascii','ignore')
        value = value.encode('utf-8') if value is not None else b''
        url.append(key + '=' + value.hex() + '&')
    return plugin + '?' + ''.join(url)


def reportUsage(addonid, action):
    host = 'xbmc-doplnky.googlecode.com'
    tc = 'UA-3971432-4'
    try:
        utmain.main({'id': addonid, 'host': host, 'tc': tc, 'action': action})
    except:
        pass


def init_usage_reporting(addonid):
    return False


def save_to_file(url, file, headers=None):
    try:
        f = open(compat_path(file), 'w', encoding="utf-8")
        f.write(request(url, headers))
        f.flush()
        os.fsync(f.fileno())
        f.close()
        return True
    except:
        traceback.print_exc()


def set_subtitles(listItem, url, headers=None):
    if not (url == '' or url == None):
        util.info('Downloading subtitles')
        local = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
        c_local = compat_path(local)
        if not os.path.exists(c_local):
            os.makedirs(c_local)
        local = os.path.join(local, 'xbmc_subs' + str(int(time.time())) + '.srt')
        util.info('Saving subtitles as %s' % local)
        if not save_to_file(url, local, headers):
            util.error('Failed to store subtitles!')
            return
        util.info('Setting subtitles to playable item')
        listItem.setSubtitles([local.encode('utf-8')])


def load_subtitles(url, headers=None):
    util.info('Downloading subtitles and load them to player...')
    if not (url == '' or url == None):
        local = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
        c_local = compat_path(local)
        if not os.path.exists(c_local):
            os.makedirs(c_local)
        local = os.path.join(local, 'xbmc_subs' + str(int(time.time())) + '.srt')
        util.info('Saving subtitles as %s' % local)
        if not save_to_file(url, local, headers):
            util.error('Failed to store subtitles!')
            return
        player = xbmc.Player()
        count = 0
        max_count = 99
        while not player.isPlaying() and count < max_count:
            count += 1
            xbmc.sleep(200)
            if count > max_count - 2:
                util.info("Cannot load subtitles, player timed out")
                return
        player.setSubtitles(local.encode('utf-8'))
        util.info('Subtitles loaded to player')


def _substitute_entity(match):
    ent = match.group(3)
    if match.group(1) == '#':
        # decoding by number
        if match.group(2) == '':
            # number is in decimal
            return chr(int(ent))
        elif match.group(2) == 'x':
            # number is in hex
            return chr(int('0x' + ent, 16))
        else:
            # they were using a name
            cp = n2cp.get(ent)
            if cp:
                return chr(cp)
            else:
                return match.group()


def decode_html(data):
    try:
        if not type(data) == str:
            data = str(data, 'utf-8', errors='ignore')
        entity_re = re.compile(r'&(#?)(x?)(\w+);')
        return entity_re.subn(_substitute_entity, data)[0]
    except:
        traceback.print_exc()
        return data


def debug(text):
    xbmc.log(str([text]), xbmc.LOGDEBUG)


def info(text):
    xbmc.log(str([text]))


def error(text):
    xbmc.log(str([text]), xbmc.LOGERROR)


def search_remove(cache, search):
    data = cache.get('search')
    if data == None or data == '':
        data = []
    else:
        data = eval(data)
    data.remove(search)
    cache.set('search', repr(data))


def search_replace(cache, search, replacement):
    data = cache.get('search')
    if data == None or data == '':
        data = []
    else:
        data = eval(data)
    index = data.index(search)
    if index > -1:
        data[index] = replacement
        cache.set('search', repr(data))


def search_add(cache, search, maximum):
    data = cache.get('search')
    if data == None or data == '':
        data = []
    else:
        data = eval(data)
    if search in data:
        data.remove(search)
    data.insert(0, search)
    remove = len(data) - maximum
    if remove > 0:
        for i in range(remove):
            data.pop()
    cache.set('search', repr(data))


def search_list(cache):
    data = cache.get('search')
    if data == None or data == '':
        data = []
    else:
        data = eval(data)
    return data


# obsolete functions ..


def get_searches(addon, server):
    local = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    c_local = compat_path(local)
    if not os.path.exists(c_local):
        os.makedirs(c_local)
    c_local = compat_path(os.path.join(local, server))
    if not os.path.exists(c_local):
        return []
    f = open(c_local, 'r')
    data = f.read()
    searches = json.loads(str(data.decode('utf-8', 'ignore')))
    f.close()
    return searches


def add_search(addon, server, search, maximum):
    searches = []
    local = xbmcvfs.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
    c_local = compat_path(local)
    if not os.path.exists(c_local):
        os.makedirs(c_local)
    c_local = compat_path(os.path.join(local, server))
    if os.path.exists(c_local):
        f = open(c_local, 'r')
        data = f.read()
        searches = json.loads(str(data.decode('utf-8', 'ignore')))
        f.close()
    if search in searches:
        searches.remove(search)
    searches.insert(0, search)
    remove = len(searches) - maximum
    if remove > 0:
        for i in range(remove):
            searches.pop()
    f = open(c_local, 'w')
    f.write(json.dumps(searches, ensure_ascii=True))
    f.close()


def delete_search_history(addon, server):
    local = xbmcvfs.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
    c_local = compat_path(local)
    if not os.path.exists(c_local):
        return
    c_local = compat_path(os.path.join(local, server))
    if os.path.exists(c_local):
        os.remove(c_local)


def remove_search(addon, server, search):
    local = xbmcvfs.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
    c_local = compat_path(local)
    if not os.path.exists(c_local):
        return
    c_local = compat_path(os.path.join(local, server))
    if os.path.exists(c_local):
        f = open(c_local, 'r')
        data = f.read()
        searches = json.loads(str(data.decode('utf-8', 'ignore')))
        f.close()
        searches.remove(search)
        f = open(c_local, 'w')
        f.write(json.dumps(searches, ensure_ascii=True))
        f.close()


# obsolete funcionts END


def download(addon, filename, url, local, notifyFinishDialog=True, headers=None):
    try:
        if headers is None:
            headers = {}
            
        util.info('Downloading %s to %s' % (url, local))
        
        # Replace old makeLegalFilename with newer method
        if hasattr(xbmcvfs, 'makeLegalFilename'):
            local = xbmcvfs.makeLegalFilename(local)
        else:
            local = xbmcvfs.validatePath(local)
            
        try:
            filename = util.replace_diacritic(util.decode_html(filename))
        except:
            filename = 'Video file'
        
        # Add .mp4 extension to both filename and local path if not present
        if not filename.lower().endswith('.mp4'):
            filename = filename + '.mp4'
            
        if not local.lower().endswith('.mp4'):
            local = local + '.mp4'
            
        icon = os.path.join(addon.getAddonInfo('path'), 'icon.png')
        notifyEnabled = addon.getSetting('download-notify') == 'true'
        notifyEvery = addon.getSetting('download-notify-every')
        notifyPercent = 1
        if int(notifyEvery) == 0:
            notifyPercent = 10
        if int(notifyEvery) == 1:
            notifyPercent = 5

        def notify(title, message, time=3000):
            try:
                # Ensure both title and message are strings
                title = str(title) if title else ''
                message = str(message) if message else ''
                xbmcgui.Dialog().notification(title, message, time=time, icon=icon, sound=False)
            except:
                traceback.print_exc()
                error('unable to show notification')

        def callback(percent, speed, est, filename):
            if percent == 0 and speed == 0:
                notify(xbmc.getLocalizedString(13413), filename)
                return
            if notifyEnabled:
                if percent > 0 and percent % notifyPercent == 0:
                    esTime = '%ss' % est
                    if est > 60:
                        esTime = '%sm' % int(est / 60)
                    try:
                        # Just use "Downloading" as title and format our own progress message
                        title = "Downloading"
                        message = f"{percent}% - {speed} KB/s {esTime}"
                        notify(title, message)
                    except Exception as e:
                        util.error('Progress notification error: %s' % str(e))

        if not os.path.exists(os.path.dirname(local)):
            os.makedirs(os.path.dirname(local))

        # Update notification to show actual filename
        notify_msg = filename
        xbmcgui.Dialog().notification('Download Started', notify_msg, xbmcgui.NOTIFICATION_INFO)
        
        downloader = Downloader(callback)
        result = downloader.download(url, local, filename, headers)
        
        if result == True:
            if xbmc.Player().isPlaying():
                notify(xbmc.getLocalizedString(20177), filename)
            else:
                if notifyFinishDialog:
                    xbmcgui.Dialog().ok(xbmc.getLocalizedString(20177), filename)
                else:
                    notify(xbmc.getLocalizedString(20177), filename)
        else:
            notify(xbmc.getLocalizedString(257), filename)
            xbmcgui.Dialog().ok(filename, xbmc.getLocalizedString(257) + ' : ' + result)
            
        # Update completion notification
        xbmcgui.Dialog().notification('Download Finished', notify_msg, xbmcgui.NOTIFICATION_INFO)
        
    except Exception as e:
        util.error('Error downloading: %s' % str(e))
        raise


class Downloader(object):

    def __init__(self, callback=None):
        self.init_time = time.time()
        self.callback = callback
        self.gran = 50
        self.percent = -1

    def download(self, remote, local, filename=None, headers={}):
        if not filename:
            filename = os.path.basename(local)
        self.filename = filename
        
        if self.callback:
            self.callback(0, 0, 0, filename)
            
        socket.setdefaulttimeout(60)
        
        try:
            # Add required headers for streaming
            if not 'User-Agent' in headers:
                headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            if not 'Accept' in headers:
                headers['Accept'] = '*/*'
            if not 'Range' in headers:
                headers['Range'] = 'bytes=0-'  # Request full file
                
            # Create request with headers
            req = urllib.request.Request(remote)
            for header in headers:
                req.add_header(header, headers[header])
            
            # Open the remote file
            response = urllib.request.urlopen(req)
            total_size = int(response.headers.get('Content-Length', 0))
            
            # Open local file for writing
            with open(local, 'wb') as f:
                block_size = 1024 * 1024  # Increased to 1MB chunks
                count = 0
                while True:
                    chunk = response.read(block_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    count += len(chunk)
                    
                    # Calculate progress
                    if total_size > 0:
                        percent = int(count * 100 / total_size)
                        if self.callback and count % (block_size * self.gran) == 0:
                            diff = time.time() - self.init_time
                            if diff <= 0:
                                diff = 1
                            speed = int((block_size * self.gran) / (1024 * diff))
                            est = int((total_size - count) / (1024 * speed))
                            
                            try:
                                self.callback(percent, speed, est, self.filename)
                            except:
                                util.error('Callback error - percent: %d, speed: %d, est: %d' % (percent, speed, est))
                                
                            self.init_time = time.time()
            
            return True
            
        except urllib.error.URLError as e:
            return f'Download failed: {str(e.reason)}'
        except socket.timeout:
            return 'Download failed: connection timeout'
        except Exception as e:
            traceback.print_exc()
            return str(e)


_diacritic_replace = {u'\u00f3': 'o',
                      u'\u0213': '-',
                      u'\u00e1': 'a',
                      u'\u010d': 'c',
                      u'\u010c': 'C',
                      u'\u010f': 'd',
                      u'\u010e': 'D',
                      u'\u00e9': 'e',
                      u'\u011b': 'e',
                      u'\u00ed': 'i',
                      u'\u0148': 'n',
                      u'\u0159': 'r',
                      u'\u0161': 's',
                      u'\u0165': 't',
                      u'\u016f': 'u',
                      u'\u00fd': 'y',
                      u'\u017e': 'z'
                      }


def replace_diacritic(string):
    ret = []
    for char in string:
        if char in _diacritic_replace:
            ret.append(_diacritic_replace[char])
        else:
            ret.append(char)
    return ''.join(ret)


def compat_path(path):
    if sys.platform.startswith('win'):
        if isinstance(path, str):
            path = path
    else:
        if isinstance(path, str):
            path = path.encode('utf-8')
    return path
