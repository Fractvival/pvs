import xbmc
import sys
import re
import pickle
import http.cookiejar
import urllib
import urllib.error
import urllib.request
import traceback
from . import cloudflare
from html.entities import name2codepoint as n2cp
import unicodedata
import json
import xbmcaddon
from typing import Optional, Any, Dict
from datetime import datetime

__addon__ = xbmcaddon.Addon('plugin.video.sosac.ph')

# Enhanced logging levels
LOG_LEVELS = {
    'DEBUG': xbmc.LOGDEBUG,
    'INFO': xbmc.LOGINFO if hasattr(xbmc, 'LOGINFO') else xbmc.LOGNOTICE,
    'WARNING': xbmc.LOGWARNING,
    'ERROR': xbmc.LOGERROR,
    'FATAL': xbmc.LOGFATAL
}

class Logger:
    """Enhanced logging class with structured logging and error tracking"""
    
    def __init__(self, name: str = "plugin.video.sosac.ph"):
        self.name = name
        self.debug_enabled = __addon__.getSetting('debug') == 'true'
    
    def _log(self, level: str, message: str, exc_info: bool = False) -> None:
        """Internal logging method with consistent formatting"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        prefix = f"[{self.name}] [{level}] [{timestamp}]"
        
        if exc_info and sys.exc_info()[0]:
            tb_text = traceback.format_exc()
            message = f"{message}\nException details:\n{tb_text}"
        
        xbmc.log(f"{prefix} {message}", LOG_LEVELS.get(level, xbmc.LOGINFO))
    
    def debug(self, message: str) -> None:
        if self.debug_enabled:
            self._log('DEBUG', str(message))
    
    def info(self, message: str) -> None:
        self._log('INFO', str(message))
    
    def warning(self, message: str) -> None:
        self._log('WARNING', str(message))
    
    def error(self, message: str, exc_info: bool = True) -> None:
        self._log('ERROR', str(message), exc_info)
    
    def fatal(self, message: str, exc_info: bool = True) -> None:
        self._log('FATAL', str(message), exc_info)

# Global logger instance
logger = Logger()

# Backward compatibility functions
def debug(text: str) -> None:
    logger.debug(text)

def info(text: str) -> None:
    logger.info(text)

def error(text: str) -> None:
    logger.error(text)

UA = 'Mozilla/6.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.5) Gecko/2008092417 Firefox/3.0.3'
_cookie_jar = None
CACHE_COOKIES = 'cookies'


def _substitute_entity(match):
    ent = match.group(3)
    if match.group(1) == '#':
        # decoding by number
        if match.group(2) == '':
            # number is in decimal
            return chr(int(ent))
        elif match.group(2) == 'x':
            # number is in hex
            return chr(int('0x' + ent, 16))
    else:
        # they were using a name
        cp = n2cp.get(ent)
        if cp:
            return chr(cp)
        else:
            return match.group()


def decode_html(data):
    if not type(data) == str:
        return data
    try:
        if not type(data) == str:
            data = str(data, 'utf-8', errors='ignore')
        entity_re = re.compile(r'&(#?)(x?)(\w+);')
        return entity_re.subn(_substitute_entity, data)[0]
    except:
        traceback.print_exc()
        return data


def request(url, headers=None):
    if headers is None:
        headers = {}
    debug('request: %s' % url)
    req = urllib.request.Request(url, headers=headers)
    req.add_header('User-Agent', UA)
    if _cookie_jar is not None:
        _cookie_jar.add_cookie_header(req)
    try:
        response = urllib.request.urlopen(req)
        data = response.read()
        response.close()
    except urllib.error.HTTPError as error:
        data = _solve_http_errors(url, error)
    debug('len(data) %s' % len(data))
    return data.decode("utf-8")


def _solve_http_errors(url, error):
    global _cookie_jar
    data = error.read()
    if error.code == 503 and 'cf-browser-verification' in data:
        data = cloudflare.solve(url, _cookie_jar, UA)
    error.close()
    return data


def params(url=None):
    if not url:
        url = sys.argv[2]
    param = {}
    paramstring = url
    if len(paramstring) >= 2:
        params = url
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    for p in param.keys():
        param[p] = bytes.fromhex(param[p]).decode('utf-8')
    return param


def cache_cookies(cache=None):
    """
    Saves cookies to cache
    """
    global _cookie_jar
    if _cookie_jar and cache is not None:
        cache.set(CACHE_COOKIES, _cookie_jar.dump())
    else:
        try:
            _cookie_jar.cache.set(CACHE_COOKIES, _cookie_jar.dump())
        except:
            pass


class _StringCookieJar(http.cookiejar.LWPCookieJar):

    def __init__(self, string=None, filename=None, delayload=False, policy=None, cache=None):
        self.cache = cache
        http.cookiejar.LWPCookieJar.__init__(self, filename, delayload, policy)
        if string and len(string) > 0:
            self._cookies = pickle.loads(str(string))

    def dump(self):
        return pickle.dumps(self._cookies)


def init_urllib(cache=None):
    """
    Initializes urllib cookie handler
    """
    global _cookie_jar
    data = None
    if cache is not None:
        data = cache.get(CACHE_COOKIES)
        _cookie_jar = _StringCookieJar(data, cache=cache)
    else:
        _cookie_jar = _StringCookieJar(data)
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_cookie_jar))
    urllib.request.install_opener(opener)


def replace_diacritic(text):
    """
    Replace diacritic characters with their ASCII equivalents
    """
    if not isinstance(text, str):
        text = str(text)
    
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ascii', 'ignore').decode('ascii')
    return text


# Enhanced utility functions
def safe_json_loads(data: str, default: Any = None) -> Any:
    """Safely parse JSON with error handling"""
    try:
        return json.loads(data)
    except (json.JSONDecodeError, TypeError) as e:
        logger.error(f"JSON parse error: {e}")
        return default

def safe_int(value: Any, default: int = 0) -> int:
    """Safely convert value to integer"""
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def safe_float(value: Any, default: float = 0.0) -> float:
    """Safely convert value to float"""
    try:
        return float(value)
    except (ValueError, TypeError):
        return default
