# -*- coding: UTF-8 -*-
"""
Configuration manager for sosac.ph addon
Provides centralized, type-safe access to addon settings
"""

import xbmcaddon
from typing import Optional, Union, List, Dict, Any
from .util import logger, safe_int, safe_float

class ConfigManager:
    """Centralized configuration manager with type safety and validation"""
    
    def __init__(self):
        self.addon = xbmcaddon.Addon('plugin.video.sosac.ph')
        self._cache = {}
        self._load_settings()
    
    def _load_settings(self) -> None:
        """Load and cache all settings"""
        try:
            # Core settings
            self.downloads_path = self._get_string('downloads', '')
            self.quality = self._get_string('quality', 'hd')
            self.enable_subs = self._get_bool('subs', True)
            self.language = self._get_string('language', 'cs')
            
            # Advanced settings
            self.debug_enabled = self._get_bool('debug', False)
            self.force_czech = self._get_bool('force-czech', False)
            self.reverse_episodes = self._get_string('order-episodes', '1') == '0'
            self.order_recently_by = self._get_int('order-recently-by', 0)
            
            # Network settings
            self.timeout = self._get_int('timeout', 30)
            self.max_retries = self._get_int('max-retries', 3)
            self.user_agent = self._get_string('user-agent', 
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            
            # Streaming service credentials
            self.streamujtv_user = self._get_string('streamujtv_user', '')
            self.streamujtv_pass = self._get_string('streamujtv_pass', '')
            self.streamujtv_location = self._get_string('streamujtv_location', '')
            
            # Download settings
            self.download_notify = self._get_bool('download-notify', True)
            self.download_notify_every = self._get_int('download-notify-every', 1)
            self.max_concurrent_downloads = self._get_int('max-concurrent-downloads', 2)
            
            logger.debug("Configuration loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
    
    def _get_string(self, key: str, default: str = '') -> str:
        """Get string setting with caching"""
        if key not in self._cache:
            self._cache[key] = self.addon.getSetting(key) or default
        return self._cache[key]
    
    def _get_bool(self, key: str, default: bool = False) -> bool:
        """Get boolean setting with caching"""
        if key not in self._cache:
            self._cache[key] = self.addon.getSetting(key) == 'true'
        return self._cache.get(key, default)
    
    def _get_int(self, key: str, default: int = 0) -> int:
        """Get integer setting with caching"""
        if key not in self._cache:
            self._cache[key] = safe_int(self.addon.getSetting(key), default)
        return self._cache[key]
    
    def _get_float(self, key: str, default: float = 0.0) -> float:
        """Get float setting with caching"""
        if key not in self._cache:
            self._cache[key] = safe_float(self.addon.getSetting(key), default)
        return self._cache[key]
    
    def set_setting(self, key: str, value: Union[str, bool, int, float]) -> None:
        """Set addon setting and update cache"""
        try:
            if isinstance(value, bool):
                self.addon.setSetting(key, 'true' if value else 'false')
            else:
                self.addon.setSetting(key, str(value))
            
            self._cache[key] = value
            logger.debug(f"Setting {key} updated to {value}")
            
        except Exception as e:
            logger.error(f"Failed to set setting {key}: {e}")
    
    def refresh(self) -> None:
        """Refresh all cached settings"""
        self._cache.clear()
        self._load_settings()
        logger.info("Configuration cache refreshed")
    
    def get_quality_options(self) -> List[str]:
        """Get available quality options"""
        return ['hd', 'sd', 'auto']
    
    def get_language_options(self) -> List[str]:
        """Get available language options"""
        return ['cs', 'sk', 'en']
    
    def validate_downloads_path(self) -> bool:
        """Validate that downloads path is accessible"""
        import os
        try:
            return os.path.exists(self.downloads_path) and os.access(self.downloads_path, os.W_OK)
        except:
            return False
    
    def get_network_config(self) -> Dict[str, Any]:
        """Get network-related configuration"""
        return {
            'timeout': self.timeout,
            'max_retries': self.max_retries,
            'user_agent': self.user_agent
        }
    
    def get_legacy_settings(self) -> Dict[str, Any]:
        """Get settings in legacy format for backward compatibility"""
        return {
            'downloads': self.downloads_path,
            'quality': self.quality,
            'subs': self.enable_subs,
            'lang': self.language
        }

# Global configuration instance
config = ConfigManager() 