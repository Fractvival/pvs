# plugin.video.sosac.ph

**Kodi Addon for movies and tv shows from sosac.tv**

## Features

- Watch online movies and TV shows from www.sosac.tv
- Full compatibility with Kodi 19+ Matrix (Python 3)
- Enhanced download functionality with progress tracking
- Subtitle support
- Multiple video quality options
- Advanced search and filtering capabilities
- Library management for TV shows and movies

## What's New in v2.2.0

### 🚀 Major Enhancements

- **Enhanced Logging System**: Structured logging with multiple log levels and better error tracking
- **Configuration Manager**: Centralized, type-safe configuration with validation
- **Network Handler**: Robust HTTP requests with retry logic and SSL support
- **Performance Optimizations**: Faster loading and better resource management
- **Modern Python**: Updated codebase with type hints and modern practices

### 🔧 New Advanced Settings

Access these in **Settings > Advanced**:

- **Debug Logging**: Enable detailed logging for troubleshooting
- **Network Timeout**: Configure request timeout (10-120 seconds)
- **Retry Attempts**: Set maximum retry attempts for failed requests (1-10)
- **Concurrent Downloads**: Control simultaneous downloads (1-5)
- **Custom User Agent**: Set custom browser identification

### 🛠️ Technical Improvements

- **Better Error Handling**: Comprehensive error catching with user-friendly messages
- **SSL Support**: Enhanced HTTPS compatibility with older streaming sites
- **Download Progress**: Real-time progress tracking for downloads
- **Configuration Validation**: Automatic validation of settings
- **Backward Compatibility**: All existing features remain unchanged

## Installation

1. Download the latest release
2. Install via Kodi: **Settings > Add-ons > Install from zip file**
3. Configure your preferences in **Settings > Add-ons > Video add-ons > Sosáč**

## Configuration

### Basic Settings
- **Downloads Folder**: Set your preferred download location
- **Video Quality**: Choose from HD, SD, or auto-selection
- **Language**: Select Czech, Slovak, or English
- **Subtitles**: Enable automatic subtitle loading

### Advanced Settings
- **Debug Mode**: Enable for detailed troubleshooting logs
- **Network Settings**: Adjust timeout and retry behavior
- **Download Limits**: Control concurrent download streams

## Troubleshooting

### Enable Debug Logging
1. Go to **Settings > Advanced > Enable debug logging**
2. Reproduce the issue
3. Check Kodi logs for detailed error information

### Common Issues
- **Downloads not working**: Check downloads folder permissions
- **Slow loading**: Increase network timeout in advanced settings
- **Connection errors**: Try increasing retry attempts

### Getting Help
- Check the [GitHub Issues](https://github.com/BlueClouDragon/plugin.video.sosac.ph/issues)
- Enable debug logging for detailed error information
- Include Kodi version and addon version when reporting issues

## Development

This addon is built with:
- **Python 3.x** (Kodi 19+ compatibility)
- **Modern Error Handling** with comprehensive logging
- **Type Safety** with type hints and validation
- **Modular Architecture** for easy maintenance

## License

GNU General Public License v2.0 - see [LICENSE.txt](LICENSE.txt)

## Changelog

See [changelog.txt](changelog.txt) for detailed version history.